#include <vega/hal.h>
#include <vega/aries.h>

static void all_leds_off(void)
{
    RGB_RED_RST;
    RGB_GREEN_RST;
    RGB_BLUE_RST;
}

int main(void)
{
    GPIO_Init(GPIOB, RGB_RED, GPIO_OUT);
    GPIO_Init(GPIOB, RGB_GREEN, GPIO_OUT);
    GPIO_Init(GPIOB, RGB_BLUE, GPIO_OUT);

    GPIO_Init(GPIOB, BTN0, GPIO_IN);
    GPIO_Init(GPIOB, BTN1, GPIO_IN);
    all_leds_off();

    while (1) {
        if (GPIO_ReadPin(GPIOB, BTN0) == 0) {
            all_leds_off();
            RGB_GREEN_SET;
            delayms(20);
        }
        else if (GPIO_ReadPin(GPIOB, BTN1) == 0) {
            all_leds_off();
            RGB_BLUE_SET;
            delayms(20);
        }
        else {
            all_leds_off();
            RGB_RED_SET;
        }
    }

    return 0;
}