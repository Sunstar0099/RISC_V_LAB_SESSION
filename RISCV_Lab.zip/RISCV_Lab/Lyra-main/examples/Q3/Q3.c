#include <vega/hal.h>

#include <stdio.h>
#include <string.h>

static const char *classify(char c)
{
    if (c >= 'A' && c <= 'Z') {
        return "Uppercase alphabet";
    }
    if (c >= 'a' && c <= 'z') {
        return "Lowercase alphabet";
    }
    if (c >= '0' && c <= '9') {
        return "Digit";
    }
    if (c == ' ' || c == '\t' || c == '\r' || c == '\n') {
        return "Whitespace";
    }
    return "Special character";
}

int main(void)
{
    char received;
    char message[100];

    UART_Init(&huart0);

    while (1) {
        UART_Receive(&huart0, &received, 1);
        sprintf(message, "Received: %c, Type: %s\r\n",
                received, classify(received));
        UART_Transmit(&huart0, message, (uint32_t)strlen(message));
    }

    return 0;
}
