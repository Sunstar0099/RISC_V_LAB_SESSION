#include <vega/hal.h>
#include <vega/aries.h>

#include <stdint.h>
#include <string.h>

static volatile uint8_t button_event = 0;
static uint8_t blue_on = 0;

int main(void)
{
    GPIO_Init(GPIOB, RGB_BLUE, GPIO_OUT);
    RGB_BLUE_RST;

    GPIO_Init(GPIOA, 3, GPIO_IN);
    GPIO_IT_Enable(3);
    UART_Init(&huart0);
    __enable_irq();

    while (1) {
        if (button_event) {
            button_event = 0;

            /* Debounce in the main loop, not in the interrupt callback. */
            delayms(150);
            button_event = 0;

            blue_on = (uint8_t)!blue_on;
            if (blue_on) {
                RGB_BLUE_SET;
                UART_Transmit(&huart0, "BLUE LED ON\r\n", 13);
            }
            else {
                RGB_BLUE_RST;
                UART_Transmit(&huart0, "BLUE LED OFF\r\n", 14);
            }
        }
    }

    return 0;
}

void GPIO_EXTICallback(uint16_t pin)
{
    if (pin == 3) {
        button_event = 1;
    }
}
