#include <vega/hal.h>
#include <vega/aries.h>

static void all_leds_off(void)
{
    RGB_RED_RST;
    RGB_GREEN_RST;
    RGB_BLUE_RST;
}

int main(void)
{
    GPIO_Init(GPIOB, RGB_RED, GPIO_OUT);
    GPIO_Init(GPIOB, RGB_GREEN, GPIO_OUT);
    GPIO_Init(GPIOB, RGB_BLUE, GPIO_OUT);
    all_leds_off();

    while (1) {
        RGB_RED_SET;
        delayms(500);
        RGB_RED_RST;
        all_leds_off();

        RGB_GREEN_SET;
        delayms(500);
        RGB_GREEN_RST;
        all_leds_off();

        RGB_BLUE_SET;
        delayms(500);
        RGB_BLUE_RST;
        all_leds_off();
    }

    return 0;
}