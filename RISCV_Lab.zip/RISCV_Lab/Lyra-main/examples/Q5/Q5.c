#include <vega/hal.h>
#include <vega/aries.h>

#include <stdint.h>

#define MILLIS(ms) ((uint32_t)((ms) * 100000UL))

int main(void)
{
    GPIO_Init(GPIOB, RGB_GREEN, GPIO_OUT);
    RGB_GREEN_RST;

    htimer0.LoadCount = MILLIS(250);
    TIMER_Init(&htimer0);
    TIMER_Start_IT(&htimer0);
    __enable_irq();

    while (1) {
        /* The timer interrupt controls the LED. */
    }

    return 0;
}

void TIMER_ElapsedCallback(TIMER_Handle_t *htimer)
{
    if (htimer == &htimer0) {
        GPIO_TogglePin(GPIOB, RGB_GREEN);
    }
}
