#include <vega/hal.h>
#include <vega/aries.h>

#include <stdint.h>
#include <string.h>

#define MILLIS(ms) ((uint32_t)((ms) * 100000UL))

int main(void)
{
    uint8_t red_on = 0;
    uint32_t previous_count;
    uint32_t current_count;
    const char *message;

    GPIO_Init(GPIOB, RGB_RED, GPIO_OUT);
    RGB_RED_RST;

    UART_Init(&huart0);

    htimer0.LoadCount = MILLIS(1000);
    TIMER_Init(&htimer0);
    TIMER_Start(&htimer0);

    previous_count = (uint32_t)TIMER_GetCount(&htimer0);

    while (1) {
        current_count = (uint32_t)TIMER_GetCount(&htimer0);

        /* A periodic down-counter reloads from a small value to LOAD.
           Detect that upward jump instead of waiting for exact zero. */
        if (current_count > previous_count) {
            red_on = (uint8_t)!red_on;
            GPIO_TogglePin(GPIOB, RGB_RED);

            message = red_on ? "RED LED ON\r\n" : "RED LED OFF\r\n";
            UART_Transmit(&huart0, message, (uint32_t)strlen(message));
        }

        previous_count = current_count;
    }

    return 0;
}